﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CORE_MVC.Models
{
    public class AneesWeb
    {
        public int ID { get; set; }

        public string Name { get; set; }

        public string PhoneNo { get; set; }

        [DataType(DataType.Date)]
        public DateTime Dob { get; set; }

        public AneesWeb()
        {

        }
    }
}