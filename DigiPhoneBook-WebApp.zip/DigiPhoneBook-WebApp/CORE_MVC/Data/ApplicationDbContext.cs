﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using CORE_MVC.Models;

namespace CORE_MVC.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<CORE_MVC.Models.AneesWeb> AneesWeb { get; set; }

        public DbSet<ApplicationUser> ApplicationUsers { get; set; }
       

    }
}
