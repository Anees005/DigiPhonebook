﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CORE_MVC.Data;
using CORE_MVC.Models;
using Microsoft.AspNetCore.Authorization;

namespace CORE_MVC.Controllers
{
    public class AneesWebsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AneesWebsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: AneesWebs
        //[Authorize]
        public async Task<IActionResult> Index()
        {
            return View(await _context.AneesWeb.ToListAsync());
        }
        public async Task<IActionResult> About()
        {
            return View(await _context.AneesWeb.ToListAsync());
        }
        [Authorize]
        // GET: ContactLogs
        public async Task<IActionResult> ContactLogs()
        {
            return View(await _context.AneesWeb.ToListAsync());
        }
        [Authorize]
        // POST: ContactLogsResult
        public async Task<IActionResult> ContactLogsResult(String SearchPhrase)
        {
            return View("Index", await _context.AneesWeb.Where(j => j.Name.Contains(SearchPhrase)).ToListAsync());
        }
        [Authorize]
        // GET: AneesWebs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var aneesWeb = await _context.AneesWeb
                .FirstOrDefaultAsync(m => m.ID == id);
            if (aneesWeb == null)
            {
                return NotFound();
            }

            return View(aneesWeb);
        }

        // GET: AneesWebs/Create
        [Authorize]
        public IActionResult Create()
        {
            return View();
        }

        // POST: AneesWebs/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Name,PhoneNo,Dob")] AneesWeb aneesWeb)
        {
            if (ModelState.IsValid)
            {
                _context.Add(aneesWeb);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(aneesWeb);
        }
        [Authorize]
        // GET: AneesWebs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var aneesWeb = await _context.AneesWeb.FindAsync(id);
            if (aneesWeb == null)
            {
                return NotFound();
            }
            return View(aneesWeb);
        }

        // POST: AneesWebs/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Name,PhoneNo,Dob")] AneesWeb aneesWeb)
        {
            if (id != aneesWeb.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(aneesWeb);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AneesWebExists(aneesWeb.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(aneesWeb);
        }
        [Authorize]
        // GET: AneesWebs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var aneesWeb = await _context.AneesWeb
                .FirstOrDefaultAsync(m => m.ID == id);
            if (aneesWeb == null)
            {
                return NotFound();
            }

            return View(aneesWeb);
        }
        [Authorize]
        // POST: AneesWebs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var aneesWeb = await _context.AneesWeb.FindAsync(id);
            _context.AneesWeb.Remove(aneesWeb);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AneesWebExists(int id)
        {
            return _context.AneesWeb.Any(e => e.ID == id);
        }
    }
}
